package com.example.serbai_control;

import android.content.Context;
import com.example.serbai_control.services.BluetoothService;

/**
 * Singleton class to share BluetoothService instance across all activities
 * This ensures only one Bluetooth connection is maintained throughout the app
 */
public class BluetoothServiceSingleton {

    private static BluetoothService instance;

    /**
     * Get the singleton instance of BluetoothService
     * @param context Application context
     * @return BluetoothService instance
     */
    public static synchronized BluetoothService getInstance(Context context) {
        if (instance == null) {
            // Create new instance with application context to avoid memory leaks
            instance = new BluetoothService(context.getApplicationContext(), null);
        }
        return instance;
    }

    /**
     * Update the callback for the BluetoothService
     * Call this in each activity's onCreate to handle Bluetooth events
     * @param callback The callback to set
     */
    public static void setCallback(BluetoothService.BluetoothCallback callback) {
        if (instance != null) {
            // Note: You'll need to add a setCallback method to BluetoothService
            // For now, this is a placeholder
        }
    }

    /**
     * Destroy the singleton instance
     * Call this when the app is completely closed
     */
    public static void destroy() {
        if (instance != null) {
            instance.disconnect();
            instance = null;
        }
    }

    /**
     * Check if instance exists and is connected
     * @return true if connected, false otherwise
     */
    public static boolean isConnected() {
        return instance != null && instance.isConnected();
    }
}