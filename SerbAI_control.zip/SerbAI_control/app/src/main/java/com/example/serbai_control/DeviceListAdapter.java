package com.example.serbai_control;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.RequiresPermission;

import java.util.List;

public class DeviceListAdapter extends ArrayAdapter<BluetoothDevice> {

    public DeviceListAdapter(Context context, List<BluetoothDevice> devices) {
        super(context, 0, devices);
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        BluetoothDevice device = getItem(position);

        TextView tvName = convertView.findViewById(android.R.id.text1);
        TextView tvAddress = convertView.findViewById(android.R.id.text2);

        String deviceName = device.getName();
        if (deviceName == null || deviceName.isEmpty()) {
            deviceName = "Appareil inconnu";
        }

        tvName.setText("📱 " + deviceName);
        tvAddress.setText("📍 " + device.getAddress());

        return convertView;
    }
}