package com.example.serbai_control;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    // Vues
    private TextView tvStatus, tvAlert, tvLog;
    private Button btnConnect, btnDisconnect, btnTest, btnStatus;
    private Button btnAuto, btnStop, btnStopUrgence;
    private Button btnModeManuel;
    private Button btnForward, btnBackward, btnLeft, btnRight;
    private Button btnPivotLeft, btnPivotRight, btnStopMoteur;
    private Button btnSpeedSlow, btnSpeedMed, btnSpeedFast;
    private LinearLayout layoutManual;

    // Bluetooth
    private String HC05_ADDRESS; // Will be loaded from settings
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothSocket socket;
    private OutputStream outputStream;
    private BufferedReader inputReader;
    private boolean isConnected = false;
    private boolean isManualMode = false;

    // Handler
    private Handler handler;
    private SimpleDateFormat timeFormat;
    private int currentSpeed = 2; // Will be loaded from settings

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handler = new Handler();
        timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

        // Initialiser les vues d'abord
        initViews();

        // Maintenant charger les paramètres (tvLog est initialisé)
        loadSettings();

        checkPermissions();
        setupListeners();

        // Auto-connect si activé dans les paramètres
        if (SettingsActivity.isAutoConnectEnabled(this)) {
            addLog("🔄 Connexion automatique activée...");
            handler.postDelayed(() -> {
                if (!isConnected) {
                    connectBluetooth();
                }
            }, 1000);
        }
    }

    private void loadSettings() {
        // Charger l'adresse MAC depuis les paramètres
        HC05_ADDRESS = SettingsActivity.getSavedMacAddress(this);

        // Charger la vitesse par défaut depuis les paramètres
        currentSpeed = SettingsActivity.getSavedDefaultSpeed(this);

        // Afficher les paramètres chargés
        addLog("⚙️ MAC: " + HC05_ADDRESS + " | Vitesse: " + currentSpeed);
    }

    private void initViews() {
        // Status et logs
        tvStatus = findViewById(R.id.tvStatus);
        tvAlert = findViewById(R.id.tvAlert);
        tvLog = findViewById(R.id.tvLog);

        // Connexion
        btnConnect = findViewById(R.id.btnConnect);
        btnDisconnect = findViewById(R.id.btnDisconnect);
        btnTest = findViewById(R.id.btnTest);
        btnStatus = findViewById(R.id.btnStatus);

        // Modes principaux
        btnAuto = findViewById(R.id.btnAuto);
        btnStop = findViewById(R.id.btnStop);
        btnStopUrgence = findViewById(R.id.btnStopUrgence);
        btnModeManuel = findViewById(R.id.btnModeManuel);

        // Layout manuel
        layoutManual = findViewById(R.id.layoutManual);

        // Contrôles direction
        btnForward = findViewById(R.id.btnForward);
        btnBackward = findViewById(R.id.btnBackward);
        btnLeft = findViewById(R.id.btnLeft);
        btnRight = findViewById(R.id.btnRight);
        btnPivotLeft = findViewById(R.id.btnPivotLeft);
        btnPivotRight = findViewById(R.id.btnPivotRight);
        btnStopMoteur = findViewById(R.id.btnStopMoteur);

        // Vitesses
        btnSpeedSlow = findViewById(R.id.btnSpeedSlow);
        btnSpeedMed = findViewById(R.id.btnSpeedMed);
        btnSpeedFast = findViewById(R.id.btnSpeedFast);

        // Désactiver tout au début
        setAllButtonsEnabled(false);
        layoutManual.setVisibility(View.GONE);

        // Update speed buttons based on saved settings
        updateSpeedButtons();

        addLog("Application démarrée - En attente de connexion");
    }

    private void checkPermissions() {
        String[] permissions = {
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.BLUETOOTH_CONNECT
        };

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, permissions, 1);
                return;
            }
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void setupListeners() {
        // === CONNEXION ===
        btnConnect.setOnClickListener(v -> connectBluetooth());
        btnDisconnect.setOnClickListener(v -> disconnectBluetooth());
        btnTest.setOnClickListener(v -> sendCommand("T"));
        btnStatus.setOnClickListener(v -> sendCommand("?"));

        // === MODES ===
        btnAuto.setOnClickListener(v -> {
            sendCommand("A");
            isManualMode = false;
            layoutManual.setVisibility(View.GONE);
            addLog("🚀 Mode Auto activé");
        });

        btnStop.setOnClickListener(v -> {
            sendCommand("S");
            isManualMode = false;
            layoutManual.setVisibility(View.GONE);
            addLog("⏸️ Robot arrêté (mode Stop)");
        });

        btnStopUrgence.setOnClickListener(v -> {
            sendCommand("X");
            isManualMode = false;
            layoutManual.setVisibility(View.GONE);
            addLog("🛑 ARRÊT URGENCE activé");
            Toast.makeText(this, "ARRÊT D'URGENCE!", Toast.LENGTH_SHORT).show();

            // Vibrate if enabled in settings
            if (SettingsActivity.isVibrationEnabled(this)) {
                vibrate(500);
            }
        });

        btnModeManuel.setOnClickListener(v -> {
            sendCommand("M");
            isManualMode = true;
            layoutManual.setVisibility(View.VISIBLE);
            setAllButtonsEnabled(true);
            addLog("🎮 Mode Manuel activé");
        });

        // === COMMANDES MANUELLES ===
        btnForward.setOnClickListener(v -> {
            sendCommand("F");
            addLog("⬆️ Avancer");
            vibrateIfEnabled(50);
        });

        btnBackward.setOnClickListener(v -> {
            sendCommand("B");
            addLog("⬇️ Reculer");
            vibrateIfEnabled(50);
        });

        btnLeft.setOnClickListener(v -> {
            sendCommand("L");
            addLog("⬅️ Gauche");
            vibrateIfEnabled(50);
        });

        btnRight.setOnClickListener(v -> {
            sendCommand("R");
            addLog("➡️ Droite");
            vibrateIfEnabled(50);
        });

        btnPivotLeft.setOnClickListener(v -> {
            sendCommand("G");
            addLog("↪️ Pivot gauche");
            vibrateIfEnabled(50);
        });

        btnPivotRight.setOnClickListener(v -> {
            sendCommand("D");
            addLog("↩️ Pivot droite");
            vibrateIfEnabled(50);
        });

        btnStopMoteur.setOnClickListener(v -> {
            sendCommand("0");
            addLog("⏸️ Stop moteur");
            vibrateIfEnabled(50);
        });

        // === VITESSES ===
        btnSpeedSlow.setOnClickListener(v -> {
            sendCommand("1");
            currentSpeed = 1;
            updateSpeedButtons();
            addLog("🐢 Vitesse LENTE");
        });

        btnSpeedMed.setOnClickListener(v -> {
            sendCommand("2");
            currentSpeed = 2;
            updateSpeedButtons();
            addLog("🚶 Vitesse MOYENNE");
        });

        btnSpeedFast.setOnClickListener(v -> {
            sendCommand("3");
            currentSpeed = 3;
            updateSpeedButtons();
            addLog("🏃 Vitesse RAPIDE");
        });
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void connectBluetooth() {
        addLog("🔄 Tentative de connexion à " + HC05_ADDRESS + "...");

        new Thread(() -> {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) {
                    showToast("Bluetooth non supporté");
                    return;
                }

                if (!adapter.isEnabled()) {
                    runOnUiThread(() -> {
                        Intent enableBt = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivity(enableBt);
                    });
                    return;
                }

                // Vérifier si l'adresse MAC est valide
                if (HC05_ADDRESS == null || HC05_ADDRESS.isEmpty()) {
                    runOnUiThread(() -> {
                        showToast("Adresse MAC non configurée");
                        addLog("❌ Adresse MAC non configurée");
                        // Ouvrir les paramètres pour configurer l'adresse MAC
                        openSettings(null);
                    });
                    return;
                }

                BluetoothDevice device = adapter.getRemoteDevice(HC05_ADDRESS);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();

                outputStream = socket.getOutputStream();
                inputReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                isConnected = true;

                runOnUiThread(() -> {
                    tvStatus.setText("🟢 Connecté");
                    tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                    setAllButtonsEnabled(true);
                    btnConnect.setEnabled(false);
                    btnDisconnect.setEnabled(true);
                    addLog("✅ Connecté au robot HC-05");
                    showToast("Connexion établie!");

                    // Set default speed from settings
                    sendCommand(String.valueOf(currentSpeed));

                    // Test connexion
                    sendCommand("T");
                });

                startReading();

            } catch (Exception e) {
                runOnUiThread(() -> {
                    showToast("Erreur: " + e.getMessage());
                    addLog("❌ Échec: " + e.getMessage());
                    disconnectBluetooth();
                });
            }
        }).start();
    }

    private void startReading() {
        new Thread(() -> {
            try {
                String line;
                while (isConnected && (line = inputReader.readLine()) != null) {
                    final String message = line;
                    runOnUiThread(() -> processMessage(message));
                }
            } catch (IOException e) {
                if (isConnected) {
                    runOnUiThread(() -> {
                        addLog("⚠️ Connexion perdue");
                        disconnectBluetooth();
                    });
                }
            }
        }).start();
    }

    private void processMessage(String message) {
        addLog("🤖 " + message);

        if (message.contains("OBSTACLE")) {
            tvAlert.setText("🚨 OBSTACLE DÉTECTÉ!");
            tvAlert.setVisibility(View.VISIBLE);
            tvAlert.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
            vibrateIfEnabled(200);
        }
        else if (message.contains("VOIE_LIBRE")) {
            tvAlert.setVisibility(View.GONE);
        }
        else if (message.contains("TEST:OK")) {
            showToast("✅ Robot opérationnel!");
        }
        else if (message.contains("ARRET")) {
            showToast("Robot arrêté");
        }
        else if (message.contains("MODE:")) {
            String mode = message.substring(message.indexOf(":") + 1);
            tvStatus.setText("🟢 Connecté - Mode: " + mode);
        }
    }

    private void sendCommand(String cmd) {
        if (!isConnected) {
            showToast("Non connecté");
            return;
        }

        new Thread(() -> {
            try {
                outputStream.write((cmd + "\n").getBytes());
                outputStream.flush();
            } catch (IOException e) {
                runOnUiThread(() -> {
                    addLog("❌ Erreur envoi");
                    disconnectBluetooth();
                });
            }
        }).start();
    }

    private void disconnectBluetooth() {
        try {
            if (outputStream != null) outputStream.close();
            if (inputReader != null) inputReader.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        isConnected = false;
        isManualMode = false;

        runOnUiThread(() -> {
            tvStatus.setText("🔴 Déconnecté");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            setAllButtonsEnabled(false);
            btnConnect.setEnabled(true);
            btnDisconnect.setEnabled(false);
            layoutManual.setVisibility(View.GONE);
            tvAlert.setVisibility(View.GONE);
            addLog("🔌 Déconnecté");
        });
    }

    private void setAllButtonsEnabled(boolean enabled) {
        btnTest.setEnabled(enabled);
        btnStatus.setEnabled(enabled);
        btnAuto.setEnabled(enabled);
        btnStop.setEnabled(enabled);
        btnStopUrgence.setEnabled(enabled);
        btnModeManuel.setEnabled(enabled);

        // Contrôles manuels seulement en mode manuel
        boolean manualEnabled = enabled && isManualMode;
        btnForward.setEnabled(manualEnabled);
        btnBackward.setEnabled(manualEnabled);
        btnLeft.setEnabled(manualEnabled);
        btnRight.setEnabled(manualEnabled);
        btnPivotLeft.setEnabled(manualEnabled);
        btnPivotRight.setEnabled(manualEnabled);
        btnStopMoteur.setEnabled(manualEnabled);
        btnSpeedSlow.setEnabled(manualEnabled);
        btnSpeedMed.setEnabled(manualEnabled);
        btnSpeedFast.setEnabled(manualEnabled);
    }

    private void updateSpeedButtons() {
        // Utiliser les couleurs appropriées pour Android
        int activeColor;
        int inactiveColor = getResources().getColor(android.R.color.darker_gray);

        if (currentSpeed == 1) {
            btnSpeedSlow.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
            btnSpeedMed.setBackgroundColor(inactiveColor);
            btnSpeedFast.setBackgroundColor(inactiveColor);
        } else if (currentSpeed == 2) {
            btnSpeedSlow.setBackgroundColor(inactiveColor);
            btnSpeedMed.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_dark));
            btnSpeedFast.setBackgroundColor(inactiveColor);
        } else if (currentSpeed == 3) {
            btnSpeedSlow.setBackgroundColor(inactiveColor);
            btnSpeedMed.setBackgroundColor(inactiveColor);
            btnSpeedFast.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }

    private void vibrateIfEnabled(long milliseconds) {
        if (SettingsActivity.isVibrationEnabled(this)) {
            vibrate(milliseconds);
        }
    }

    private void vibrate(long milliseconds) {
        try {
            android.os.Vibrator vibrator = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(android.os.VibrationEffect.createOneShot(milliseconds,
                            android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(milliseconds);
                }
            }
        } catch (Exception e) {
            // Vibration not available
        }
    }

    private void addLog(String message) {
        if (tvLog == null) {
            return; // Ne pas ajouter de log si tvLog n'est pas initialisé
        }

        String time = timeFormat.format(new Date());
        String current = tvLog.getText().toString();
        String newLog = time + " - " + message + "\n" + current;

        // Limiter à 50 lignes
        String[] lines = newLog.split("\n");
        if (lines.length > 50) {
            StringBuilder limited = new StringBuilder();
            for (int i = 0; i < 50; i++) {
                limited.append(lines[i]).append("\n");
            }
            newLog = limited.toString();
        }

        tvLog.setText(newLog);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnectBluetooth();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload settings when returning from SettingsActivity
        loadSettings();
    }

    // Navigation vers autres activités
    public void openSettings(View view) {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    public void openMonitor(View view) {
        if (!isConnected) {
            showToast("Connectez-vous d'abord au robot");
            return;
        }
        Intent intent = new Intent(this, MonitorActivity.class);
        startActivity(intent);
    }

    public void openSequencer(View view) {
        if (!isConnected) {
            showToast("Connectez-vous d'abord au robot");
            return;
        }
        Intent intent = new Intent(this, SequencerActivity.class);
        startActivity(intent);
    }
}