package com.example.serbai_control;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MonitorActivity extends AppCompatActivity {

    private TextView tvConnectionStatus, tvLastUpdate;
    private TextView tvSensorFront, tvIRLeft, tvIRMiddle, tvIRRight;
    private TextView tvSensorLogs, tvBatteryInfo;
    private LineChart chartTelemetry;

    private Handler handler;
    private SimpleDateFormat timeFormat;

    // Données pour le graphique (distance seulement - données réelles)
    private ArrayList<Entry> distanceEntries;
    private int dataIndex = 0;

    // Simulation de données reçues du robot
    private int lastDistance = 50;
    private int lastIRLeft = 400;
    private int lastIRMiddle = 800;
    private int lastIRRight = 350;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitor);

        handler = new Handler();
        timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

        initViews();
        setupChart();
        startMonitoring();
    }

    private void initViews() {
        tvConnectionStatus = findViewById(R.id.tvConnectionStatus);
        tvLastUpdate = findViewById(R.id.tvLastUpdate);
        tvSensorFront = findViewById(R.id.tvSensorFront);
        tvIRLeft = findViewById(R.id.tvIRLeft);
        tvIRMiddle = findViewById(R.id.tvIRMiddle);
        tvIRRight = findViewById(R.id.tvIRRight);
        tvSensorLogs = findViewById(R.id.tvSensorLogs);
        tvBatteryInfo = findViewById(R.id.tvBatteryInfo);
        chartTelemetry = findViewById(R.id.chartTelemetry);

        // Status connexion
        tvConnectionStatus.setText("🟢 CONNECTÉ AU ROBOT");
        tvConnectionStatus.setTextColor(Color.GREEN);

        // Info batterie (simulation - matériel non disponible)
        tvBatteryInfo.setText("⚠️ Capteur batterie non installé\n(Ajoutez un diviseur de tension ou INA219)");
        tvBatteryInfo.setTextColor(Color.YELLOW);
    }

    private void setupChart() {
        distanceEntries = new ArrayList<>();

        // Configuration du graphique
        chartTelemetry.setTouchEnabled(true);
        chartTelemetry.setDragEnabled(true);
        chartTelemetry.setScaleEnabled(true);
        chartTelemetry.setPinchZoom(true);
        chartTelemetry.setDrawGridBackground(false);
        chartTelemetry.getDescription().setEnabled(true);
        chartTelemetry.getDescription().setText("Distance Obstacle (HC-SR04)");
        chartTelemetry.getDescription().setTextColor(Color.WHITE);

        // Configuration de l'axe X
        XAxis xAxis = chartTelemetry.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setLabelCount(10);
        xAxis.setTextColor(Color.WHITE);

        // Configuration de l'axe Y gauche
        YAxis leftAxis = chartTelemetry.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setAxisMaximum(200f);
        leftAxis.setDrawGridLines(true);
        leftAxis.setTextColor(Color.WHITE);

        // Configuration de l'axe Y droit
        YAxis rightAxis = chartTelemetry.getAxisRight();
        rightAxis.setEnabled(false);

        // Créer le dataset
        LineDataSet distanceDataSet = new LineDataSet(distanceEntries, "Distance (cm)");
        distanceDataSet.setColor(Color.CYAN);
        distanceDataSet.setCircleColor(Color.CYAN);
        distanceDataSet.setLineWidth(3f);
        distanceDataSet.setCircleRadius(4f);
        distanceDataSet.setDrawCircleHole(false);
        distanceDataSet.setValueTextSize(0f); // Pas de valeurs sur les points
        distanceDataSet.setDrawFilled(true);
        distanceDataSet.setFillColor(Color.CYAN);
        distanceDataSet.setFillAlpha(50);

        LineData lineData = new LineData(distanceDataSet);
        chartTelemetry.setData(lineData);
        chartTelemetry.invalidate();
    }

    private void startMonitoring() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateMonitoringData();
                handler.postDelayed(this, 500); // Mise à jour toutes les 500ms
            }
        }, 500);
    }

    private void updateMonitoringData() {
        // Mettre à jour l'heure
        String currentTime = timeFormat.format(new Date());
        tvLastUpdate.setText("Dernière mise à jour: " + currentTime);

        // SIMULATION DE RÉCEPTION DE DONNÉES DU ROBOT
        // Dans une version réelle, ces données viendraient du Bluetooth
        // Format attendu du robot:
        // "DIST:45" - Distance obstacle
        // "IR:350,820,400" - Capteurs IR (Gauche,Milieu,Droite)

        // Pour la démo, on simule des variations légères
        lastDistance = lastDistance + (int)(Math.random() * 10) - 5;
        if (lastDistance < 5) lastDistance = 5;
        if (lastDistance > 200) lastDistance = 200;

        lastIRLeft = lastIRLeft + (int)(Math.random() * 100) - 50;
        if (lastIRLeft < 0) lastIRLeft = 0;
        if (lastIRLeft > 1023) lastIRLeft = 1023;

        lastIRMiddle = lastIRMiddle + (int)(Math.random() * 100) - 50;
        if (lastIRMiddle < 0) lastIRMiddle = 0;
        if (lastIRMiddle > 1023) lastIRMiddle = 1023;

        lastIRRight = lastIRRight + (int)(Math.random() * 100) - 50;
        if (lastIRRight < 0) lastIRRight = 0;
        if (lastIRRight > 1023) lastIRRight = 1023;

        // Afficher capteur ultrason (AVANT - HC-SR04)
        tvSensorFront.setText(lastDistance + " cm");
        if (lastDistance < 20) {
            tvSensorFront.setTextColor(Color.RED);
        } else if (lastDistance < 50) {
            tvSensorFront.setTextColor(Color.YELLOW);
        } else {
            tvSensorFront.setTextColor(Color.GREEN);
        }

        // Afficher capteurs IR (TCRT5000)
        tvIRLeft.setText("IR Gauche: " + lastIRLeft);
        tvIRLeft.setTextColor(lastIRLeft > 650 ? Color.RED : Color.GREEN);

        tvIRMiddle.setText("IR Milieu: " + lastIRMiddle);
        tvIRMiddle.setTextColor(lastIRMiddle > 650 ? Color.RED : Color.GREEN);

        tvIRRight.setText("IR Droite: " + lastIRRight);
        tvIRRight.setTextColor(lastIRRight > 650 ? Color.RED : Color.GREEN);

        // Mettre à jour le graphique (distance)
        if (dataIndex < 40) {
            distanceEntries.add(new Entry(dataIndex, lastDistance));
            dataIndex++;

            chartTelemetry.getData().notifyDataChanged();
            chartTelemetry.notifyDataSetChanged();
            chartTelemetry.setVisibleXRangeMaximum(40);
            chartTelemetry.moveViewToX(dataIndex - 1);
        } else {
            // Garder seulement les 40 derniers points
            distanceEntries.remove(0);
            for (int i = 0; i < distanceEntries.size(); i++) {
                Entry e = distanceEntries.get(i);
                e.setX(i);
            }
            distanceEntries.add(new Entry(distanceEntries.size(), lastDistance));

            chartTelemetry.getData().notifyDataChanged();
            chartTelemetry.notifyDataSetChanged();
            chartTelemetry.moveViewToX(distanceEntries.size() - 1);
        }

        // Ajouter des logs
        String logEntry = currentTime + " - Distance:" + lastDistance + "cm | " +
                "IR(L:" + lastIRLeft + " M:" + lastIRMiddle + " R:" + lastIRRight + ")\n";
        String currentLogs = tvSensorLogs.getText().toString();

        // Limiter à 15 lignes
        String[] lines = (logEntry + currentLogs).split("\n");
        StringBuilder limitedLogs = new StringBuilder();
        for (int i = 0; i < Math.min(15, lines.length); i++) {
            limitedLogs.append(lines[i]).append("\n");
        }
        tvSensorLogs.setText(limitedLogs.toString());

        // Avertissement si obstacle proche
        if (lastDistance < 30) {
            String warning = currentTime + " - ⚠️ OBSTACLE PROCHE! Distance: " + lastDistance + "cm\n";
            tvSensorLogs.setText("🚨 " + warning + tvSensorLogs.getText().toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}