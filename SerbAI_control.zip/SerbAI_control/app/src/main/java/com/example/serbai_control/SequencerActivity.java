package com.example.serbai_control;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SequencerActivity extends AppCompatActivity {

    private Button btnAddCommand, btnSaveSequence, btnLoadSequence;
    private Button btnPlay, btnPause, btnStopSequence, btnClear;
    private Button btnCmdForward, btnCmdLeft, btnCmdRight, btnCmdBackward;
    private Button btnCmdWait, btnCmdStop;

    private ListView lvSequence;
    private EditText etDuration;
    private Spinner spinnerSpeed;
    private TextView tvSequenceLog, tvSequenceStatus;

    private ArrayList<SequenceCommand> commandSequence;
    private ArrayAdapter<String> sequenceAdapter;
    private ArrayList<String> displaySequence;

    private boolean isPlaying = false;
    private boolean isPaused = false;
    private int currentCommandIndex = 0;
    private Handler handler;

    // Classe pour stocker les commandes
    private static class SequenceCommand {
        String action; // F, B, L, R, etc.
        int duration; // en millisecondes
        int speed; // 1, 2, 3
        String display; // Texte à afficher

        SequenceCommand(String action, int duration, int speed, String display) {
            this.action = action;
            this.duration = duration;
            this.speed = speed;
            this.display = display;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sequencer);

        commandSequence = new ArrayList<>();
        displaySequence = new ArrayList<>();
        handler = new Handler();

        initViews();
        setupListeners();
        setupSpinner();
    }

    private void initViews() {
        btnAddCommand = findViewById(R.id.btnAddCommand);
        btnSaveSequence = findViewById(R.id.btnSaveSequence);
        btnLoadSequence = findViewById(R.id.btnLoadSequence);
        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);
        btnStopSequence = findViewById(R.id.btnStopSequence);
        btnClear = findViewById(R.id.btnClear);

        btnCmdForward = findViewById(R.id.btnCmdForward);
        btnCmdLeft = findViewById(R.id.btnCmdLeft);
        btnCmdRight = findViewById(R.id.btnCmdRight);
        btnCmdBackward = findViewById(R.id.btnCmdBackward);
        btnCmdWait = findViewById(R.id.btnCmdWait);
        btnCmdStop = findViewById(R.id.btnCmdStop);

        lvSequence = findViewById(R.id.lvSequence);
        etDuration = findViewById(R.id.etDuration);
        spinnerSpeed = findViewById(R.id.spinnerSpeed);
        tvSequenceLog = findViewById(R.id.tvSequenceLog);
        tvSequenceStatus = findViewById(R.id.tvSequenceStatus);

        // Adapter pour la liste de séquence
        sequenceAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, displaySequence);
        lvSequence.setAdapter(sequenceAdapter);

        tvSequenceStatus.setText("📋 Séquence vide - Ajoutez des commandes");
    }

    private void setupSpinner() {
        List<String> speedLevels = Arrays.asList("🐢 Lent", "🚶 Moyen", "🏃 Rapide");
        ArrayAdapter<String> speedAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, speedLevels);
        speedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSpeed.setAdapter(speedAdapter);
        spinnerSpeed.setSelection(1); // Moyen par défaut
    }

    private void setupListeners() {
        // Commandes prédéfinies
        btnCmdForward.setOnClickListener(v -> addCommandToSequence("AVANCER", "F"));
        btnCmdLeft.setOnClickListener(v -> addCommandToSequence("GAUCHE", "L"));
        btnCmdRight.setOnClickListener(v -> addCommandToSequence("DROITE", "R"));
        btnCmdBackward.setOnClickListener(v -> addCommandToSequence("RECULER", "B"));
        btnCmdWait.setOnClickListener(v -> addCommandToSequence("ATTENDRE", "W"));
        btnCmdStop.setOnClickListener(v -> addCommandToSequence("STOP", "0"));

        btnPlay.setOnClickListener(v -> playSequence());
        btnPause.setOnClickListener(v -> pauseSequence());
        btnStopSequence.setOnClickListener(v -> stopSequence());
        btnClear.setOnClickListener(v -> clearSequence());

        btnSaveSequence.setOnClickListener(v -> {
            addLog("💾 Sauvegarde locale (fonctionnalité à implémenter)");
            Toast.makeText(this, "Séquence sauvegardée en mémoire", Toast.LENGTH_SHORT).show();
        });

        btnLoadSequence.setOnClickListener(v -> loadDemoSequence());

        // Supprimer une commande avec appui long
        lvSequence.setOnItemLongClickListener((parent, view, position, id) -> {
            commandSequence.remove(position);
            displaySequence.remove(position);
            sequenceAdapter.notifyDataSetChanged();
            updateStatus();
            addLog("🗑️ Commande " + (position + 1) + " supprimée");
            return true;
        });
    }

    private void addCommandToSequence(String commandType, String action) {
        String durationText = etDuration.getText().toString();
        int duration = 1000; // Valeur par défaut

        try {
            duration = Integer.parseInt(durationText);
            if (duration < 100) duration = 100;
            if (duration > 10000) duration = 10000;
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Durée invalide, 1000ms utilisé", Toast.LENGTH_SHORT).show();
        }

        int speedIndex = spinnerSpeed.getSelectedItemPosition();
        int speed = speedIndex + 1; // 1, 2, ou 3
        String speedEmoji = speedIndex == 0 ? "🐢" : (speedIndex == 1 ? "🚶" : "🏃");

        String displayText = (commandSequence.size() + 1) + ". ";

        switch (commandType) {
            case "AVANCER":
                displayText += "▶️ AVANCER - " + duration + "ms - " + speedEmoji;
                break;
            case "GAUCHE":
                displayText += "⬅️ GAUCHE - " + duration + "ms - " + speedEmoji;
                break;
            case "DROITE":
                displayText += "➡️ DROITE - " + duration + "ms - " + speedEmoji;
                break;
            case "RECULER":
                displayText += "⬇️ RECULER - " + duration + "ms - " + speedEmoji;
                break;
            case "ATTENDRE":
                displayText += "⏱️ PAUSE - " + duration + "ms";
                action = "W"; // Pas de commande moteur, juste attendre
                speed = 0;
                break;
            case "STOP":
                displayText += "⏹️ STOP MOTEURS - " + duration + "ms";
                break;
        }

        SequenceCommand cmd = new SequenceCommand(action, duration, speed, displayText);
        commandSequence.add(cmd);
        displaySequence.add(displayText);
        sequenceAdapter.notifyDataSetChanged();
        lvSequence.smoothScrollToPosition(commandSequence.size() - 1);

        updateStatus();
        addLog("➕ Ajouté: " + commandType + " (" + duration + "ms)");
    }

    private void playSequence() {
        if (commandSequence.isEmpty()) {
            Toast.makeText(this, "❌ Séquence vide!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isPlaying && isPaused) {
            // Reprendre
            isPaused = false;
            addLog("▶️ Reprise de la séquence...");
            continueSequence();
            return;
        }

        isPlaying = true;
        isPaused = false;
        currentCommandIndex = 0;

        btnPlay.setEnabled(false);
        btnPause.setEnabled(true);
        btnStopSequence.setEnabled(true);

        addLog("▶️ DÉMARRAGE de la séquence (" + commandSequence.size() + " commandes)");
        tvSequenceStatus.setText("▶️ EN COURS - Commande 1/" + commandSequence.size());

        executeNextCommand();
    }

    private void executeNextCommand() {
        if (!isPlaying || isPaused || currentCommandIndex >= commandSequence.size()) {
            if (currentCommandIndex >= commandSequence.size() && isPlaying) {
                // Séquence terminée
                finishSequence();
            }
            return;
        }

        final SequenceCommand cmd = commandSequence.get(currentCommandIndex);
        final int cmdNumber = currentCommandIndex + 1;

        runOnUiThread(() -> {
            addLog("➡️ [" + cmdNumber + "/" + commandSequence.size() + "] " + cmd.display);
            tvSequenceStatus.setText("▶️ EN COURS - Commande " + cmdNumber + "/" + commandSequence.size());
            lvSequence.setSelection(currentCommandIndex);
        });

        // ENVOYER LA COMMANDE AU ROBOT VIA BLUETOOTH
        // NOTE: Vous devez implémenter sendCommandToRobot() qui utilise le BluetoothService
        if (!cmd.action.equals("W")) {
            // Définir la vitesse d'abord
            if (cmd.speed > 0) {
                sendCommandToRobot(String.valueOf(cmd.speed));
            }
            // Ensuite envoyer la commande de mouvement
            sendCommandToRobot(cmd.action);
        }

        // Attendre la durée spécifiée, puis passer à la suivante
        handler.postDelayed(() -> {
            // Arrêter le mouvement après la durée
            if (!cmd.action.equals("W") && !cmd.action.equals("0")) {
                sendCommandToRobot("0"); // Stop moteurs
            }

            currentCommandIndex++;
            executeNextCommand();
        }, cmd.duration);
    }

    private void continueSequence() {
        btnPause.setEnabled(true);
        executeNextCommand();
    }

    private void pauseSequence() {
        if (!isPlaying) return;

        isPaused = true;
        btnPause.setEnabled(false);

        // Arrêter les moteurs
        sendCommandToRobot("0");

        addLog("⏸️ Séquence en PAUSE à la commande " + (currentCommandIndex + 1));
        tvSequenceStatus.setText("⏸️ EN PAUSE - Commande " + (currentCommandIndex + 1) + "/" + commandSequence.size());
        Toast.makeText(this, "⏸️ Pause - Cliquez Play pour reprendre", Toast.LENGTH_SHORT).show();
    }

    private void stopSequence() {
        isPlaying = false;
        isPaused = false;
        currentCommandIndex = 0;

        // Arrêter les moteurs
        sendCommandToRobot("0");

        handler.removeCallbacksAndMessages(null);

        btnPlay.setEnabled(true);
        btnPause.setEnabled(false);
        btnStopSequence.setEnabled(false);

        addLog("⏹️ Séquence ARRÊTÉE");
        tvSequenceStatus.setText("⏹️ ARRÊTÉE - Prêt à rejouer");
        Toast.makeText(this, "⏹️ Séquence arrêtée", Toast.LENGTH_SHORT).show();
    }

    private void finishSequence() {
        isPlaying = false;
        isPaused = false;

        // Arrêter les moteurs
        sendCommandToRobot("0");

        btnPlay.setEnabled(true);
        btnPause.setEnabled(false);
        btnStopSequence.setEnabled(false);

        addLog("✅ Séquence TERMINÉE avec succès!");
        tvSequenceStatus.setText("✅ TERMINÉE - " + commandSequence.size() + " commandes exécutées");
        Toast.makeText(this, "✅ Séquence terminée!", Toast.LENGTH_LONG).show();
    }

    private void clearSequence() {
        if (isPlaying) {
            Toast.makeText(this, "❌ Arrêtez d'abord la séquence", Toast.LENGTH_SHORT).show();
            return;
        }

        commandSequence.clear();
        displaySequence.clear();
        sequenceAdapter.notifyDataSetChanged();
        updateStatus();
        addLog("🗑️ Séquence effacée");
    }

    private void loadDemoSequence() {
        if (isPlaying) {
            Toast.makeText(this, "❌ Arrêtez d'abord la séquence en cours", Toast.LENGTH_SHORT).show();
            return;
        }

        commandSequence.clear();
        displaySequence.clear();

        // Séquence de démonstration
        commandSequence.add(new SequenceCommand("2", 100, 2, "1. 🚶 Vitesse Moyenne"));
        commandSequence.add(new SequenceCommand("F", 2000, 2, "2. ▶️ AVANCER - 2000ms"));
        commandSequence.add(new SequenceCommand("W", 500, 0, "3. ⏱️ PAUSE - 500ms"));
        commandSequence.add(new SequenceCommand("L", 1000, 1, "4. ⬅️ GAUCHE - 1000ms - 🐢"));
        commandSequence.add(new SequenceCommand("F", 1500, 3, "5. ▶️ AVANCER - 1500ms - 🏃"));
        commandSequence.add(new SequenceCommand("0", 500, 0, "6. ⏹️ STOP - 500ms"));

        for (SequenceCommand cmd : commandSequence) {
            displaySequence.add(cmd.display);
        }

        sequenceAdapter.notifyDataSetChanged();
        updateStatus();
        addLog("📂 Séquence de démo chargée (6 commandes)");
        Toast.makeText(this, "📂 Séquence de démo chargée", Toast.LENGTH_SHORT).show();
    }

    private void updateStatus() {
        if (commandSequence.isEmpty()) {
            tvSequenceStatus.setText("📋 Séquence vide - Ajoutez des commandes");
        } else {
            tvSequenceStatus.setText("📋 " + commandSequence.size() + " commande(s) programmée(s)");
        }
    }

    private void sendCommandToRobot(String command) {
        // TODO: Implémenter l'envoi via BluetoothService
        // Pour l'instant, juste un log
        addLog("📤 Envoi: " + command);

        // Dans une version complète, vous feriez:
        // BluetoothService.getInstance().sendCommand(command);
    }

    private void addLog(String message) {
        String currentLogs = tvSequenceLog.getText().toString();
        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date());
        String newLog = timestamp + " - " + message + "\n" + currentLogs;

        // Limiter à 20 lignes
        String[] lines = newLog.split("\n");
        if (lines.length > 20) {
            StringBuilder limited = new StringBuilder();
            for (int i = 0; i < 20; i++) {
                limited.append(lines[i]).append("\n");
            }
            newLog = limited.toString();
        }

        tvSequenceLog.setText(newLog);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isPlaying) {
            stopSequence();
        }
        handler.removeCallbacksAndMessages(null);
    }
}