package com.example.serbai_control;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;

import com.example.serbai_control.services.BluetoothService;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {

    // Views
    private EditText etMacAddress;
    private Button btnScanDevices, btnSave, btnDefault, btnEmergencyTest;
    private ListView lvDevices;
    private RadioGroup rgDefaultSpeed;
    private RadioButton rbSlow, rbMedium, rbFast;
    private CheckBox cbAutoConnect, cbVibrationFeedback, cbSoundFeedback;
    private SeekBar sbAutoStop;
    private TextView tvAutoStopValue;

    // Bluetooth Service
    private BluetoothService bluetoothService;
    private DeviceListAdapter deviceAdapter;
    private List<BluetoothDevice> deviceList;

    // SharedPreferences
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "RobotControlPrefs";
    private static final String KEY_MAC_ADDRESS = "mac_address";
    private static final String KEY_DEFAULT_SPEED = "default_speed";
    private static final String KEY_AUTO_CONNECT = "auto_connect";
    private static final String KEY_VIBRATION = "vibration_feedback";
    private static final String KEY_SOUND = "sound_feedback";
    private static final String KEY_AUTO_STOP = "auto_stop_timeout";

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize SharedPreferences
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Initialize Bluetooth Service
        bluetoothService = new BluetoothService(this, new BluetoothService.BluetoothCallback() {
            @Override
            public void onMessageReceived(String message) {
                // Not used in settings
            }

            @Override
            public void onConnectionStatus(boolean connected, String status) {
                // Not used in settings
            }

            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            @Override
            public void onDeviceList(Set<BluetoothDevice> devices) {
                displayDeviceList(devices);
            }
        });

        initViews();
        loadSettings();
        setupListeners();
    }

    private void initViews() {
        etMacAddress = findViewById(R.id.etMacAddress);
        btnScanDevices = findViewById(R.id.btnScanDevices);
        lvDevices = findViewById(R.id.lvDevices);

        rgDefaultSpeed = findViewById(R.id.rgDefaultSpeed);
        rbSlow = findViewById(R.id.rbSlow);
        rbMedium = findViewById(R.id.rbMedium);
        rbFast = findViewById(R.id.rbFast);

        cbAutoConnect = findViewById(R.id.cbAutoConnect);
        cbVibrationFeedback = findViewById(R.id.cbVibrationFeedback);
        cbSoundFeedback = findViewById(R.id.cbSoundFeedback);

        sbAutoStop = findViewById(R.id.sbAutoStop);
        tvAutoStopValue = findViewById(R.id.tvAutoStopValue);

        btnSave = findViewById(R.id.btnSave);
        btnDefault = findViewById(R.id.btnDefault);
        btnEmergencyTest = findViewById(R.id.btnEmergencyTest);

        // Setup device list
        deviceList = new ArrayList<>();
        deviceAdapter = new DeviceListAdapter(this, deviceList);
        lvDevices.setAdapter(deviceAdapter);
    }

    private void loadSettings() {
        // Load MAC address
        String macAddress = prefs.getString(KEY_MAC_ADDRESS, "00:00:13:00:61:0D");
        etMacAddress.setText(macAddress);

        // Load default speed
        int speed = prefs.getInt(KEY_DEFAULT_SPEED, 2);
        switch (speed) {
            case 1:
                rbSlow.setChecked(true);
                break;
            case 2:
                rbMedium.setChecked(true);
                break;
            case 3:
                rbFast.setChecked(true);
                break;
        }

        // Load checkboxes
        cbAutoConnect.setChecked(prefs.getBoolean(KEY_AUTO_CONNECT, false));
        cbVibrationFeedback.setChecked(prefs.getBoolean(KEY_VIBRATION, true));
        cbSoundFeedback.setChecked(prefs.getBoolean(KEY_SOUND, true));

        // Load auto-stop timeout
        int autoStop = prefs.getInt(KEY_AUTO_STOP, 30);
        sbAutoStop.setProgress(autoStop);
        tvAutoStopValue.setText(autoStop + " secondes");
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void setupListeners() {
        // Scan devices button
        btnScanDevices.setOnClickListener(v -> scanDevices());

        // Device list click
        lvDevices.setOnItemClickListener((parent, view, position, id) -> {
            BluetoothDevice device = deviceList.get(position);
            etMacAddress.setText(device.getAddress());
            lvDevices.setVisibility(View.GONE);
            Toast.makeText(this, "Appareil sélectionné: " + device.getName(),
                    Toast.LENGTH_SHORT).show();
        });

        // Auto-stop seekbar
        sbAutoStop.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvAutoStopValue.setText(progress + " secondes");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Emergency test button
        btnEmergencyTest.setOnClickListener(v -> testEmergencyStop());

        // Save button
        btnSave.setOnClickListener(v -> saveSettings());

        // Default button
        btnDefault.setOnClickListener(v -> resetToDefaults());
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void scanDevices() {
        if (!bluetoothService.checkPermissions()) {
            bluetoothService.requestPermissions(this);
            return;
        }

        if (!bluetoothService.isBluetoothEnabled()) {
            Toast.makeText(this, "Activez le Bluetooth", Toast.LENGTH_SHORT).show();
            return;
        }

        Set<BluetoothDevice> pairedDevices = bluetoothService.getPairedDevices();
        if (pairedDevices != null && !pairedDevices.isEmpty()) {
            displayDeviceList(pairedDevices);
        } else {
            Toast.makeText(this, "Aucun appareil appairé trouvé", Toast.LENGTH_SHORT).show();
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private void displayDeviceList(Set<BluetoothDevice> devices) {
        deviceList.clear();
        deviceList.addAll(devices);
        deviceAdapter.notifyDataSetChanged();
        lvDevices.setVisibility(View.VISIBLE);
        Toast.makeText(this, devices.size() + " appareils trouvés", Toast.LENGTH_SHORT).show();
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = prefs.edit();

        // Save MAC address
        String macAddress = etMacAddress.getText().toString().trim();
        if (isValidMacAddress(macAddress)) {
            editor.putString(KEY_MAC_ADDRESS, macAddress);
        } else {
            Toast.makeText(this, "Adresse MAC invalide", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save default speed
        int speed = 2;
        if (rbSlow.isChecked()) speed = 1;
        else if (rbMedium.isChecked()) speed = 2;
        else if (rbFast.isChecked()) speed = 3;
        editor.putInt(KEY_DEFAULT_SPEED, speed);

        // Save checkboxes
        editor.putBoolean(KEY_AUTO_CONNECT, cbAutoConnect.isChecked());
        editor.putBoolean(KEY_VIBRATION, cbVibrationFeedback.isChecked());
        editor.putBoolean(KEY_SOUND, cbSoundFeedback.isChecked());

        // Save auto-stop timeout
        editor.putInt(KEY_AUTO_STOP, sbAutoStop.getProgress());

        // Apply changes
        editor.apply();

        Toast.makeText(this, "✅ Paramètres sauvegardés", Toast.LENGTH_SHORT).show();
        finish(); // Return to previous activity
    }

    private void resetToDefaults() {
        etMacAddress.setText("00:00:13:00:61:0D");
        rbMedium.setChecked(true);
        cbAutoConnect.setChecked(false);
        cbVibrationFeedback.setChecked(true);
        cbSoundFeedback.setChecked(true);
        sbAutoStop.setProgress(30);
        tvAutoStopValue.setText("30 secondes");

        Toast.makeText(this, "Paramètres par défaut restaurés", Toast.LENGTH_SHORT).show();
    }

    private void testEmergencyStop() {
        if (bluetoothService.isConnected()) {
            bluetoothService.sendCommand("X");
            Toast.makeText(this, "🛑 Commande d'arrêt d'urgence envoyée",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Robot non connecté", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidMacAddress(String mac) {
        // MAC address format: XX:XX:XX:XX:XX:XX
        String macPattern = "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$";
        return mac.matches(macPattern);
    }

    // Getter methods for other activities to access settings
    public static String getSavedMacAddress(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(KEY_MAC_ADDRESS, "00:00:13:00:61:0D");
    }

    public static int getSavedDefaultSpeed(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_DEFAULT_SPEED, 2);
    }

    public static boolean isAutoConnectEnabled(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_AUTO_CONNECT, false);
    }

    public static boolean isVibrationEnabled(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_VIBRATION, true);
    }

    public static boolean isSoundEnabled(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_SOUND, true);
    }

    public static int getAutoStopTimeout(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_AUTO_STOP, 30);
    }
}