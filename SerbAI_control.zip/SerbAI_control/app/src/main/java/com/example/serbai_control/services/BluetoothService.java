package com.example.serbai_control.services;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.annotation.RequiresPermission;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class BluetoothService {

    // UUID pour SPP (Serial Port Profile)
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Adresse MAC par défaut du HC-05 (À MODIFIER)
    private static final String DEFAULT_DEVICE_ADDRESS = "00:00:13:00:61:0D";
    private static final String DEFAULT_DEVICE_NAME = "HC-05";

    // Composants Bluetooth
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private BufferedReader inputReader;

    // Context et Handler
    private Context context;
    private Handler handler;

    // Variables d'état
    private boolean isConnected = false;
    private boolean isConnecting = false;

    // Interface de callback
    public interface BluetoothCallback {
        void onMessageReceived(String message);
        void onConnectionStatus(boolean connected, String status);
        void onDeviceList(Set<BluetoothDevice> devices);
    }

    private BluetoothCallback callback;

    // Constructeur
    public BluetoothService(Context context, BluetoothCallback callback) {
        this.context = context;
        this.callback = callback;
        this.handler = new Handler(Looper.getMainLooper());

        // Initialiser l'adapter Bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    // Vérifier si Bluetooth est supporté
    public boolean isBluetoothSupported() {
        return bluetoothAdapter != null;
    }

    // Vérifier si Bluetooth est activé
    public boolean isBluetoothEnabled() {
        return bluetoothAdapter != null && bluetoothAdapter.isEnabled();
    }

    // Demander l'activation du Bluetooth
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public void requestEnableBluetooth(Activity activity) {
        if (!isBluetoothEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            activity.startActivityForResult(enableBtIntent, 1);
        }
    }

    // Vérifier les permissions
    public boolean checkPermissions() {
        if (ContextCompat.checkSelfPermission(context,
                Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        if (ContextCompat.checkSelfPermission(context,
                Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        // Pour Android 6.0+
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }

        return true;
    }

    // Demander les permissions
    public void requestPermissions(Activity activity) {
        String[] permissions;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            permissions = new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        } else {
            permissions = new String[]{
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        }

        ActivityCompat.requestPermissions(activity, permissions, 100);
    }

    // Obtenir les appareils appairés
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public Set<BluetoothDevice> getPairedDevices() {
        if (bluetoothAdapter != null && checkPermissions()) {
            return bluetoothAdapter.getBondedDevices();
        }
        return null;
    }

    // Connecter à un appareil spécifique
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public void connectToDevice(String deviceAddress) {
        if (isConnecting || isConnected) return;

        isConnecting = true;
        notifyConnectionStatus(false, "Connexion en cours...");

        new Thread(() -> {
            try {
                // Vérifier permissions
                if (!checkPermissions()) {
                    showToast("Permissions Bluetooth requises");
                    isConnecting = false;
                    return;
                }

                // Vérifier Bluetooth activé
                if (!isBluetoothEnabled()) {
                    showToast("Activez le Bluetooth");
                    isConnecting = false;
                    return;
                }

                // Récupérer l'appareil
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);

                // Créer le socket
                bluetoothSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);

                // Se connecter (timeout de 5 secondes)
                bluetoothSocket.connect();

                // Obtenir les flux d'entrée/sortie
                outputStream = bluetoothSocket.getOutputStream();
                inputReader = new BufferedReader(new InputStreamReader(bluetoothSocket.getInputStream()));

                // Mettre à jour l'état
                isConnected = true;
                isConnecting = false;

                // Notifier la connexion réussie
                notifyConnectionStatus(true, "Connecté à " + device.getName());
                showToast("Connecté avec succès!");

                // Démarrer la lecture des messages
                startReadingMessages();

            } catch (IOException e) {
                isConnecting = false;
                isConnected = false;

                // Fermer le socket en cas d'erreur
                closeSocket();

                // Notifier l'échec
                notifyConnectionStatus(false, "Échec connexion: " + e.getMessage());
                showToast("Échec connexion: " + e.getMessage());

            } catch (IllegalArgumentException e) {
                isConnecting = false;
                notifyConnectionStatus(false, "Adresse MAC invalide");
                showToast("Adresse MAC invalide");
            }
        }).start();
    }

    // Connecter au HC-05 par défaut
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public void connect() {
        connectToDevice(DEFAULT_DEVICE_ADDRESS);
    }

    // Démarrer la lecture des messages
    private void startReadingMessages() {
        new Thread(() -> {
            try {
                String message;
                while (isConnected && (message = inputReader.readLine()) != null) {
                    final String finalMessage = message;
                    handler.post(() -> {
                        if (callback != null) {
                            callback.onMessageReceived(finalMessage);
                        }
                    });
                }
            } catch (IOException e) {
                // Déconnexion
                if (isConnected) {
                    disconnect();
                    notifyConnectionStatus(false, "Déconnecté");
                }
            }
        }).start();
    }

    // Envoyer un message
    public void sendMessage(String message) {
        if (!isConnected || outputStream == null) {
            showToast("Non connecté");
            return;
        }

        new Thread(() -> {
            try {
                outputStream.write((message + "\n").getBytes());
                outputStream.flush();
            } catch (IOException e) {
                handler.post(() -> {
                    showToast("Erreur d'envoi");
                    disconnect();
                });
            }
        }).start();
    }

    // Envoyer une commande (pour le robot)
    public void sendCommand(String command) {
        sendMessage(command);
    }

    // Déconnecter
    public void disconnect() {
        isConnected = false;
        isConnecting = false;

        closeSocket();

        notifyConnectionStatus(false, "Déconnecté");
        showToast("Déconnecté");
    }

    // Fermer le socket
    private void closeSocket() {
        try {
            if (outputStream != null) {
                outputStream.close();
                outputStream = null;
            }
            if (inputReader != null) {
                inputReader.close();
                inputReader = null;
            }
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
                bluetoothSocket = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Vérifier si connecté
    public boolean isConnected() {
        return isConnected;
    }

    // Obtenir le nom de l'appareil par défaut
    public String getDefaultDeviceName() {
        return DEFAULT_DEVICE_NAME;
    }

    // Obtenir l'adresse de l'appareil par défaut
    public String getDefaultDeviceAddress() {
        return DEFAULT_DEVICE_ADDRESS;
    }

    // Notifier le statut de connexion
    private void notifyConnectionStatus(final boolean connected, final String status) {
        handler.post(() -> {
            if (callback != null) {
                callback.onConnectionStatus(connected, status);
            }
        });
    }

    // Afficher un toast
    private void showToast(final String message) {
        handler.post(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
    }
}